#!/usr/bin/env python3
"""
Script to generate an Adobe .ACO file from a CSV swatch file using OS file explorer dialogs.
"""

import tkinter as tk
from tkinter import filedialog
import sys
import traceback
import logging

# Import the function from the adobe_color_swatch package
# Ensure you've installed the package with: pip3 install git+https://github.com/kdybicz/adobe-color-swatch
from swatch.swatch import convert_csv_file_to_aco

def main():
    # Set up logging if needed
    logging.basicConfig(level=logging.INFO, format='%(message)s')

    # Initialize Tkinter and hide the main window.
    root = tk.Tk()
    root.withdraw()

    # Prompt the user to select a CSV file using the OS file explorer.
    print("Please select the CSV file containing your swatches.")
    csv_file_path = filedialog.askopenfilename(
        title="Select CSV File",
        filetypes=[("CSV Files", "*.csv")]
    )
    if not csv_file_path:
        print("No CSV file selected. Exiting.")
        sys.exit(1)
    print(f"CSV file selected: {csv_file_path}")

    # Prompt the user to choose where to save the resulting ACO file.
    print("Please choose where to save the Adobe Color Swatch (.ACO) file.")
    aco_file_path = filedialog.asksaveasfilename(
        title="Save ACO File",
        defaultextension=".aco",
        filetypes=[("ACO Files", "*.aco")]
    )
    if not aco_file_path:
        print("No save location selected. Exiting.")
        sys.exit(1)
    print(f"ACO file will be saved as: {aco_file_path}")

    try:
        # Open the CSV file for reading (as text)
        with open(csv_file_path, 'r', encoding='utf-8') as csv_file:
            # Open the output file for writing in binary mode.
            with open(aco_file_path, 'wb') as aco_file:
                # Generate the ACO file from CSV using the adobe_color_swatch package method.
                convert_csv_file_to_aco(csv_file, aco_file)
                print(f"ACO file generated and saved to {aco_file_path}.")
    except Exception as e:
        print("An error occurred during conversion:")
        print(str(e))
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()
