@echo off
REM =============================================================================
REM NOBLE ARCHITECTURE - CLOUDFLARE WORKERS DEPLOYMENT SCRIPT
REM =============================================================================
REM
REM PURPOSE    : Deploy the Project Admin API to Cloudflare Workers
REM AUTHOR     : Adam Noble - Noble Architecture
REM CREATED    : 31-Jan-2026
REM
REM USAGE:
REM   deploy.bat           - Deploy to development (workers.dev)
REM   deploy.bat prod      - Deploy to production
REM
REM MODULE STRUCTURE:
REM   src/CloudflareWorker__Main__.js           - Main entry point
REM   src/handlers/CloudflareHandler__Auth__.js      - Authentication
REM   src/handlers/CloudflareHandler__R2__.js        - R2 operations
REM   src/handlers/CloudflareHandler__Signature__.js - Signature storage
REM
REM =============================================================================

echo.
echo ============================================================
echo  NOBLE ARCHITECTURE - Cloudflare Workers Deployment
echo ============================================================
echo.
echo Module Structure:
echo   CloudflareWorker__Main__.js
echo   ^|-- CloudflareHandler__Auth__.js
echo   ^|-- CloudflareHandler__R2__.js
echo   ^+-- CloudflareHandler__Signature__.js
echo.

REM Check if wrangler is installed
where wrangler >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Wrangler CLI not found!
    echo.
    echo Please install Wrangler first:
    echo   npm install -g wrangler
    echo.
    echo Then login to Cloudflare:
    echo   wrangler login
    echo.
    pause
    exit /b 1
)

REM Set the API token environment variable
set CLOUDFLARE_API_TOKEN=AGka1oAelB1nMIL7uXnZpmffMb5pfrjHRNZlznMV

REM Check deployment environment
if "%1"=="prod" (
    echo Deploying to PRODUCTION...
    echo.
    wrangler deploy --env production
) else (
    echo Deploying to DEVELOPMENT (workers.dev)...
    echo.
    wrangler deploy
)

echo.
if %ERRORLEVEL% equ 0 (
    echo ============================================================
    echo  Deployment successful!
    echo ============================================================
    echo.
    echo Your worker is now live at:
    if "%1"=="prod" (
        echo   https://na-projectadmin-api.noble-architecture.workers.dev
    ) else (
        echo   https://na-projectadmin-api.adam-fb3.workers.dev
    )
    echo.
    echo Test endpoints:
    echo   /health              - Health check
    echo   /ip                  - Client IP
    echo   /projectadmin/auth   - Authentication
    echo   /projectadmin/signature - Signatures
    echo   /r2/*                - R2 operations
    echo.
) else (
    echo ============================================================
    echo  Deployment failed! Check the error above.
    echo ============================================================
)

pause
