export function formatSVG(svgNode) {
  const clone = svgNode.cloneNode(true);
  
  if (!clone.hasAttribute('xmlns')) {
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  }

  // Use the canvas-paper rect to determine the actual document size
  const paper = clone.querySelector('#canvas-paper');
  if (paper) {
    const w = paper.getAttribute('width');
    const h = paper.getAttribute('height');
    clone.setAttribute('width', w);
    clone.setAttribute('height', h);
    clone.setAttribute('viewBox', `0 0 ${w} ${h}`);
    paper.remove();
  } else {
    // Fallback if paper not found
    const viewBox = clone.getAttribute('viewBox');
    if (viewBox && !clone.hasAttribute('width')) {
      const parts = viewBox.split(' ');
      if (parts.length === 4) {
        clone.setAttribute('width', parts[2]);
        clone.setAttribute('height', parts[3]);
      }
    }
  }
  
  clone.removeAttribute('style');

  // Remove old background rect logic if still present (fallback)
  const bg = clone.querySelector('rect[fill="#ffffff"]');
  if (bg && bg.getAttribute('width') == svgNode.getAttribute('viewBox').split(' ')[2]) {
     bg.remove();
  }

  // Remove temporary highlight strokes added by SelectionManager
  const elements = clone.querySelectorAll('*');
  elements.forEach(el => {
    if (el.dataset && el.dataset.originalStroke) {
      el.setAttribute('stroke', el.dataset.originalStroke);
      delete el.dataset.originalStroke;
    }
    // Remove all dataset attributes to clean up SVG
    Object.keys(el.dataset).forEach(key => {
       if (key !== 'layerId' && key !== 'layerName') {
         delete el.dataset[key];
         el.removeAttribute('data-' + key.replace(/([A-Z])/g, "-$1").toLowerCase());
       }
    });
  });

  return formatNode(clone, 0);
}

function formatNode(node, depth) {
  if (node.nodeType === Node.TEXT_NODE) {
    const text = node.textContent.trim();
    return text ? text : '';
  }

  if (node.nodeType !== Node.ELEMENT_NODE) {
    return '';
  }

  const indent = '  '.repeat(depth);
  const nextIndent = '  '.repeat(depth + 1);
  const attrIndent = '  '.repeat(depth + 2);
  
  let result = `${indent}<${node.tagName.toLowerCase()}`;

  // Sort attributes: xmlns, viewBox, width, height first, then alphabetical, except d which goes first
  const attrs = Array.from(node.attributes).sort((a, b) => {
    const order = { 'xmlns': 1, 'viewBox': 2, 'width': 3, 'height': 4, 'd': 5 };
    const aOrder = order[a.name] || 100;
    const bOrder = order[b.name] || 100;
    if (aOrder !== bOrder) return aOrder - bOrder;
    return a.name.localeCompare(b.name);
  });

  // If node is path or has many attributes, put attributes on new lines
  const multiLineAttrs = attrs.length > 3 || node.tagName.toLowerCase() === 'path';

  attrs.forEach(attr => {
    let val = attr.value;
    if (attr.name === 'd') {
      // Format 'd' attribute
      val = '\n' + attrIndent + '  ' + val.replace(/([MmLlHhVvCcSsQqTtAaZz])/g, '\n' + attrIndent + '  $1').trim().replace(/\n\s*\n/g, '\n') + '\n' + attrIndent;
    }
    
    if (multiLineAttrs) {
      result += `\n${nextIndent}${attr.name}="${val}"`;
    } else {
      result += ` ${attr.name}="${val}"`;
    }
  });

  if (node.childNodes.length === 0) {
    if (multiLineAttrs) {
      result += `\n${indent}/>`;
    } else {
      result += ` />`;
    }
  } else {
    if (multiLineAttrs) {
      result += `\n${indent}>`;
    } else {
      result += `>`;
    }
    
    let hasElementChildren = false;
    Array.from(node.childNodes).forEach(child => {
      const childStr = formatNode(child, depth + 1);
      if (childStr) {
        if (child.nodeType === Node.ELEMENT_NODE) hasElementChildren = true;
        result += `\n${childStr}`;
      }
    });

    if (hasElementChildren) {
      result += `\n${indent}</${node.tagName.toLowerCase()}>`;
    } else {
      result += `</${node.tagName.toLowerCase()}>`;
    }
  }

  return result;
}
