export class SVGUploadManager {
  constructor(appState, eventBus, svgCanvas) {
    this.appState = appState;
    this.eventBus = eventBus;
    this.svgCanvas = svgCanvas;

    this.uploadBtn = document.getElementById('upload-svg-btn');
    this.uploadInput = document.getElementById('svg-upload-input');

    if (this.uploadBtn && this.uploadInput) {
      this.uploadBtn.addEventListener('click', () => {
        this.uploadInput.click();
      });

      this.uploadInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
          this.handleSVGUpload(event.target.result, file.name);
        };
        reader.readAsText(file);
        
        // Reset input so the same file can be uploaded again if needed
        this.uploadInput.value = '';
      });
    }
  }

  handleSVGUpload(svgContent, filename) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(svgContent, 'image/svg+xml');
    const uploadedSvg = doc.documentElement;

    if (uploadedSvg.tagName.toLowerCase() !== 'svg') {
      console.error('Invalid SVG file');
      return;
    }

    // Create a new layer for the uploaded SVG
    const layerName = filename.replace('.svg', '') + ' (Import)';
    this.appState.addLayer(layerName);
    
    // We need to wait for the layer to be created in the DOM
    setTimeout(() => {
      // Get the children of the uploaded SVG and append them to the active layer
      const layerId = this.appState.activeLayerId;
      const layerGroup = this.svgCanvas.layerGroups[layerId];
      
      if (!layerGroup) return;

      const children = Array.from(uploadedSvg.childNodes);
      children.forEach(child => {
        // Only import elements, skip text nodes/comments unless needed
        if (child.nodeType === Node.ELEMENT_NODE) {
          // ensure child has originalStroke data if needed, or just let SelectionManager handle it
          if (child.hasAttribute('stroke')) {
            child.dataset.originalStroke = child.getAttribute('stroke');
          }
          layerGroup.appendChild(document.importNode(child, true));
        }
      });

      this.eventBus.emit('layers:changed', this.appState.layers);
      this.eventBus.emit('selection:changed', []); // trigger redraw/update
    }, 50);
  }
}
