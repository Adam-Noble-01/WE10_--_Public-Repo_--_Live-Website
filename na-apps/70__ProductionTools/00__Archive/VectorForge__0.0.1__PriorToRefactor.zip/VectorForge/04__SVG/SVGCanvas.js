
    export class SVGCanvas {
      constructor(appState, eventBus, viewBoxController) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.container = document.getElementById('canvas-container');
        
        this.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        this.svg.style.width = '100%';
        this.svg.style.height = '100%';
        this.svg.setAttribute('viewBox', `0 0 ${appState.canvasWidth} ${appState.canvasHeight}`);
        
        // Define canvas rect
        this.canvasRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        this.canvasRect.id = 'canvas-paper';
        this.canvasRect.setAttribute('width', appState.canvasWidth);
        this.canvasRect.setAttribute('height', appState.canvasHeight);
        this.canvasRect.setAttribute('fill', '#ffffff');
        // A simple drop shadow could be added here via SVG filter if desired
        this.svg.appendChild(this.canvasRect);

        this.layerGroups = {};
        this.createLayerGroup(appState.activeLayerId);
        
        this.container.appendChild(this.svg);
        
        this.svg.addEventListener('mousemove', (e) => {
          const pt = this.getSVGPoint(e);
          this.eventBus.emit('cursor:moved', pt);
        });

        this.eventBus.on('layers:changed', () => this.updateLayers());
      }
      
      getSVGPoint(e) {
        const pt = this.svg.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const transformedPt = pt.matrixTransform(this.svg.getScreenCTM().inverse());
        
        // Basic snapping
        if (this.appState.snapToGrid) {
          const gridSize = this.appState.gridSize || 10;
          transformedPt.x = Math.round(transformedPt.x / gridSize) * gridSize;
          transformedPt.y = Math.round(transformedPt.y / gridSize) * gridSize;
        }
        
        return transformedPt;
      }

      createLayerGroup(id) {
        if (!this.layerGroups[id]) {
          const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
          g.setAttribute('data-layer-id', id);
          this.svg.appendChild(g);
          this.layerGroups[id] = g;
        }
      }

      updateLayers() {
        // Remove deleted layers
        const layerIds = this.appState.layers.map(l => l.id);
        for (const id in this.layerGroups) {
          if (!layerIds.includes(id)) {
            this.layerGroups[id].remove();
            delete this.layerGroups[id];
          }
        }
        
        // Add new layers and update names
        this.appState.layers.forEach(l => {
          this.createLayerGroup(l.id);
          this.layerGroups[l.id].setAttribute('data-layer-name', l.name);
          // sort according to state? (reverse order in DOM)
        });
      }

      addElement(el) {
        const layerId = this.appState.activeLayerId;
        if (this.layerGroups[layerId]) {
          this.layerGroups[layerId].appendChild(el);
        }
      }
    }
  