import { AppState } from './01__Core/AppState.js';
import { EventBus } from './01__Core/EventBus.js';
import { HotkeyManager } from './01__Core/HotkeyManager.js';
import { SVGCanvas } from './04__SVG/SVGCanvas.js';
import { SVGUploadManager } from './04__SVG/SVGUploadManager.js';
import { ToolbarUI } from './02__UI/ToolbarUI.js';
import { LayersPanelUI } from './02__UI/LayersPanelUI.js';
import { PropertiesPanelUI } from './02__UI/PropertiesPanelUI.js';
import { CodePanelUI } from './02__UI/CodePanelUI.js';
import { StatusBarUI } from './02__UI/StatusBarUI.js';
import { ViewBoxController } from './03__AppModules/System__Navigation/ViewBoxController.js';
import { SelectionManager } from './01__Core/SelectionManager.js';
import { LineTool } from './03__AppModules/System__LineworkTools/LineTool.js';
import { RectangleTool } from './03__AppModules/System__LineworkTools/RectangleTool.js';
import { PathTool } from './03__AppModules/System__LineworkTools/PathTool.js';
import { UndoManager } from './01__Core/UndoManager.js';

document.addEventListener('DOMContentLoaded', () => {
  const eventBus = new EventBus();
  const appState = new AppState(eventBus);
  const hotkeyManager = new HotkeyManager(eventBus);
  
  const viewBoxController = new ViewBoxController(appState, eventBus);
  const svgCanvas = new SVGCanvas(appState, eventBus, viewBoxController);
  const selectionManager = new SelectionManager(appState, eventBus, svgCanvas);
  const undoManager = new UndoManager(appState, eventBus, svgCanvas);
  
  const toolbar = new ToolbarUI(appState, eventBus);
  const layersPanel = new LayersPanelUI(appState, eventBus, svgCanvas);
  const propsPanel = new PropertiesPanelUI(appState, eventBus, selectionManager);
  const codePanel = new CodePanelUI(appState, eventBus, svgCanvas);
  const statusBar = new StatusBarUI(appState, eventBus);
  const svgUploadManager = new SVGUploadManager(appState, eventBus, svgCanvas);

  // Initialize Tools
  const tools = {
    'select': null, // default behavior handled by SelectionManager
    'line': new LineTool(appState, eventBus, svgCanvas),
    'rect': new RectangleTool(appState, eventBus, svgCanvas),
    'path': new PathTool(appState, eventBus, svgCanvas)
  };

  // Initialize Snap Toggle
  const snapBtn = document.getElementById('snap-toggle-btn');
  snapBtn.addEventListener('click', () => {
    appState.snapToGrid = !appState.snapToGrid;
    if (appState.snapToGrid) {
      snapBtn.textContent = 'Snap: On';
      snapBtn.style.background = 'var(--color-slate-200)';
      snapBtn.style.color = 'var(--color-slate-800)';
    } else {
      snapBtn.textContent = 'Snap: Off';
      snapBtn.style.background = 'transparent';
      snapBtn.style.color = 'var(--color-slate-600)';
    }
  });

  appState.setTools(tools);
  appState.setTool('select');
});