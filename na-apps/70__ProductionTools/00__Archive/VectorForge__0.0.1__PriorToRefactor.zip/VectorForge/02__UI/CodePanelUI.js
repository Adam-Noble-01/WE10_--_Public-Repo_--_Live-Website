import { formatSVG } from '../04__SVG/SVGSerialization.js';

export class CodePanelUI {
  constructor(appState, eventBus, svgCanvas) {
    this.appState = appState;
    this.eventBus = eventBus;
    this.svgCanvas = svgCanvas;

    this.tabBtns = document.querySelectorAll('.tab-btn');
    this.propsContent = document.getElementById('props-content');
    this.codeContent = document.getElementById('code-content');
    
    this.tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        this.tabBtns.forEach(b => {
          b.classList.remove('active');
          b.style.color = 'var(--color-slate-500)';
          b.style.background = 'transparent';
          b.style.borderBottom = '2px solid transparent';
        });
        btn.classList.add('active');
        btn.style.color = 'var(--color-slate-800)';
        btn.style.background = 'white';
        btn.style.borderBottom = '2px solid var(--color-blue-600)';

        if (btn.dataset.target === 'props-content') {
          this.propsContent.style.display = 'block';
          this.codeContent.style.display = 'none';
        } else {
          this.propsContent.style.display = 'none';
          this.codeContent.style.display = 'block';
          this.updateCode();
        }
      });
    });

    this.eventBus.on('selection:changed', () => {
      if (this.codeContent.style.display === 'block') this.updateCode();
    });
    this.eventBus.on('layers:changed', () => {
      if (this.codeContent.style.display === 'block') this.updateCode();
    });
    // Add event listener to svg canvas directly to catch drawing changes
    this.svgCanvas.svg.addEventListener('mouseup', () => {
      setTimeout(() => {
        if (this.codeContent.style.display === 'block') this.updateCode();
      }, 50);
    });

    this.eventBus.on('hotkey:syncCode', () => {
      if (this.codeContent.style.display === 'block') {
        this.applyCodeToCanvas();
      }
    });
  }

  updateCode() {
    // Only serialize the content of the SVG that represents the document
    const svgCode = formatSVG(this.svgCanvas.svg);
    // Escape HTML to display as text
    this.codeContent.value = svgCode;
  }

  applyCodeToCanvas() {
    const code = this.codeContent.value;
    const parser = new DOMParser();
    const doc = parser.parseFromString(code, 'image/svg+xml');
    
    // Check for parse errors
    if (doc.querySelector('parsererror')) {
      console.warn('SVG parse error');
      return;
    }

    const newSvg = doc.documentElement;
    if (newSvg.tagName.toLowerCase() !== 'svg') return;

    if (newSvg.hasAttribute('width')) {
      const w = parseFloat(newSvg.getAttribute('width'));
      if (!isNaN(w)) {
        this.appState.canvasWidth = w;
      }
    }
    if (newSvg.hasAttribute('height')) {
      const h = parseFloat(newSvg.getAttribute('height'));
      if (!isNaN(h)) {
        this.appState.canvasHeight = h;
      }
    }
    
    // We do NOT parse/override the viewBox on this.svgCanvas.svg here, 
    // because ViewBoxController manages it for zoom and pan.
    // The width/height from the imported SVG are applied to the #canvas-paper below.

    // Clear existing selection
    this.eventBus.emit('selection:changed', []);

    // Clear canvas
    while (this.svgCanvas.svg.firstChild) {
      this.svgCanvas.svg.removeChild(this.svgCanvas.svg.firstChild);
    }
    
    // Reset layers in appState
    this.appState.layers = [];
    this.svgCanvas.layerGroups = {};

    let hasLayers = false;

    // Reconstruct layers
    Array.from(newSvg.children).forEach(child => {
      if (child.tagName.toLowerCase() === 'g' && child.hasAttribute('data-layer-id')) {
        hasLayers = true;
        const layerId = child.getAttribute('data-layer-id');
        const layerName = child.getAttribute('data-layer-name') || 'Layer';
        
        this.appState.layers.push({ id: layerId, name: layerName, visible: true, locked: false });
        
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.dataset.layerId = layerId;
        g.dataset.layerName = layerName;
        
        // Move children
        Array.from(child.childNodes).forEach(node => {
          g.appendChild(document.importNode(node, true));
        });
        
        this.svgCanvas.layerGroups[layerId] = g;
        this.svgCanvas.svg.appendChild(g);
      }
    });

    if (!hasLayers) {
      // If no layers were found (e.g. pasted a flat SVG), create a default one
      this.appState.addLayer('Layer 1');
      const activeLayer = this.svgCanvas.layerGroups[this.appState.activeLayerId];
      Array.from(newSvg.childNodes).forEach(node => {
        if (node.nodeType === Node.ELEMENT_NODE && node.tagName.toLowerCase() !== 'rect' && node.tagName.toLowerCase() !== 'defs') { // skip default rect or definitions if present, or just add everything
          activeLayer.appendChild(document.importNode(node, true));
        }
      });
    } else {
      if (this.appState.layers.length > 0) {
        this.appState.activeLayerId = this.appState.layers[this.appState.layers.length - 1].id;
      }
    }

    // Restore background if needed
    const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    bg.id = 'canvas-paper';
    bg.setAttribute('width', this.appState.canvasWidth);
    bg.setAttribute('height', this.appState.canvasHeight);
    bg.setAttribute('fill', '#ffffff');
    this.svgCanvas.svg.insertBefore(bg, this.svgCanvas.svg.firstChild);

    this.eventBus.emit('layers:changed', this.appState.layers);
    
    // trigger a cursor update so status bar knows new size
    this.eventBus.emit('cursor:moved', { x: 0, y: 0 });
    this.eventBus.emit('canvas:resized');
  }
}
