
    export class ToolbarUI {
      constructor(appState, eventBus) {
        this.appState = appState;
        this.buttons = document.querySelectorAll('.toolbar button');
        this.buttons.forEach(btn => {
          btn.addEventListener('click', () => {
            this.appState.setTool(btn.dataset.tool);
          });
        });

        eventBus.on('tool:changed', (toolName) => {
          this.buttons.forEach(btn => {
            if (btn.dataset.tool === toolName) btn.classList.add('active');
            else btn.classList.remove('active');
          });
        });

        eventBus.on('hotkey:tool_select', () => this.appState.setTool('select'));
        eventBus.on('hotkey:tool_line', () => this.appState.setTool('line'));
        eventBus.on('hotkey:tool_rect', () => this.appState.setTool('rect'));
        eventBus.on('hotkey:tool_path', () => this.appState.setTool('path'));
      }
    }
  