
    export class StatusBarUI {
      constructor(appState, eventBus) {
        this.zoomEl = document.getElementById('zoom-level');
        this.posEl = document.getElementById('cursor-pos');
        this.canvasPx = document.getElementById('canvas-px');
        this.canvasMm = document.getElementById('canvas-mm');
        
        eventBus.on('cursor:moved', (pt) => {
          this.posEl.innerText = `${Math.round(pt.x)}, ${Math.round(pt.y)}`;
        });
        
        eventBus.on('zoom:changed', (pct) => {
          this.zoomEl.innerText = `${Math.round(pct)}%`;
        });

        eventBus.on('canvas:resized', () => this.updateCanvasInfo(appState));

        this.updateCanvasInfo(appState);
      }
      updateCanvasInfo(appState) {
        this.canvasPx.innerText = `${appState.canvasWidth}x${appState.canvasHeight} px`;
        this.canvasMm.innerText = `${(appState.canvasWidth / appState.pxPerMm).toFixed(1)}x${(appState.canvasHeight / appState.pxPerMm).toFixed(1)} mm`;
      }
    }
  