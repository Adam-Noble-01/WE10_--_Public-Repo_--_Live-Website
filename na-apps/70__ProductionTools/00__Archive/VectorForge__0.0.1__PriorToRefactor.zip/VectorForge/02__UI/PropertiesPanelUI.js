
    export class PropertiesPanelUI {
      constructor(appState, eventBus, selectionManager) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.selectionManager = selectionManager;
        this.panelEl = document.getElementById('props-content');

        this.eventBus.on('selection:changed', (selectedElements) => {
          this.render(selectedElements);
        });
      }
      render(elements) {
        if (elements.length === 0) {
          this.panelEl.innerHTML = 'Select an object';
          return;
        }
        if (elements.length > 1) {
          this.panelEl.innerHTML = `${elements.length} objects selected`;
          return;
        }
        
        const el = elements[0];
        let html = `<div class="props-group">
          <label>Type: ${el.tagName}</label>
        </div>
        <div class="props-group">
          <label>Stroke Width</label>
          <input type="number" id="prop-stroke-width" value="${el.getAttribute('stroke-width') || 1}">
        </div>`;
        
        if (el.tagName === 'rect') {
           html += `<div class="props-group">
             <label>Width</label>
             <input type="number" id="prop-width" value="${Math.round(el.getAttribute('width'))}">
           </div>`;
        }

        this.panelEl.innerHTML = html;

        const swInput = document.getElementById('prop-stroke-width');
        if (swInput) {
          swInput.addEventListener('change', (e) => {
            el.setAttribute('stroke-width', e.target.value);
          });
        }
        
        const wInput = document.getElementById('prop-width');
        if (wInput) {
          wInput.addEventListener('change', (e) => {
            el.setAttribute('width', e.target.value);
          });
        }
      }
    }
  