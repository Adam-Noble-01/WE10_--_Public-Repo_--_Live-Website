
    export class LayersPanelUI {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.listEl = document.getElementById('layer-list');
        this.addBtn = document.getElementById('add-layer-btn');
        
        this.addBtn.addEventListener('click', () => {
          this.appState.addLayer('Layer ' + (this.appState.layers.length + 1));
        });

        this.eventBus.on('layers:changed', (layers) => {
          this.render(layers);
        });
        
        this.render(this.appState.layers);
      }
      render(layers) {
        this.listEl.innerHTML = '';
        layers.forEach(l => {
          const div = document.createElement('div');
          div.className = 'layer-item' + (l.id === this.appState.activeLayerId ? ' active' : '');
          
          div.innerHTML = `
            <div class="layer-icon" style="width: 12px; height: 12px; margin-right: 8px; flex-shrink: 0; color: ${l.id === this.appState.activeLayerId ? 'var(--color-blue-600)' : 'var(--color-slate-400)'}">
              <svg fill="currentColor" viewBox="0 0 20 20"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/></svg>
            </div>
            <span style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${l.name}</span>
          `;

          div.addEventListener('click', () => this.appState.setActiveLayer(l.id));
          div.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showContextMenu(e.pageX, e.pageY, l.id);
          });
          this.listEl.appendChild(div);
        });
      }
      
      showContextMenu(x, y, layerId) {
        // remove existing
        const existing = document.getElementById('layer-context-menu');
        if (existing) existing.remove();

        const menu = document.createElement('div');
        menu.id = 'layer-context-menu';
        menu.style.position = 'fixed';
        menu.style.left = x + 'px';
        menu.style.top = y + 'px';
        menu.style.background = '#2d2d2d';
        menu.style.border = '1px solid #3d3d3d';
        menu.style.padding = '4px 0';
        menu.style.zIndex = '1000';
        menu.style.boxShadow = '0 4px 6px rgba(0,0,0,0.3)';
        menu.style.borderRadius = '4px';

        const createItem = (text, onClick) => {
          const item = document.createElement('div');
          item.innerText = text;
          item.style.padding = '6px 16px';
          item.style.cursor = 'pointer';
          item.style.fontSize = '12px';
          item.addEventListener('mouseenter', () => item.style.background = '#444');
          item.addEventListener('mouseleave', () => item.style.background = 'transparent');
          item.addEventListener('click', () => {
             onClick();
             menu.remove();
          });
          return item;
        };

        menu.appendChild(createItem('Rename', () => {
          const l = this.appState.layers.find(ly => ly.id === layerId);
          const newName = prompt('Enter new name:', l ? l.name : '');
          if (newName) this.appState.renameLayer(layerId, newName);
        }));

        menu.appendChild(createItem('Delete', () => {
          if (this.appState.layers.length > 1) {
            this.appState.deleteLayer(layerId);
          } else {
            alert('Cannot delete the last layer.');
          }
        }));

        document.body.appendChild(menu);

        const closeMenu = (e) => {
          if (!menu.contains(e.target)) {
            menu.remove();
            document.removeEventListener('click', closeMenu);
            document.removeEventListener('contextmenu', closeMenu);
          }
        };
        setTimeout(() => {
          document.addEventListener('click', closeMenu);
          document.addEventListener('contextmenu', closeMenu);
        }, 0);
      }
    }
  