import fs from 'fs';
import path from 'path';

const files = {
  'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG Vector Editor</title>
  <link rel="stylesheet" href="./05__Styles/EditorTheme.css">
</head>
<body>
  <div id="app">
    <header class="top-bar">
      <div class="logo">SVG Editor</div>
      <div class="status-bar" id="status-bar">
        <span>Zoom: <span id="zoom-level">100%</span></span>
        <span>Pos: <span id="cursor-pos">0, 0</span></span>
        <span>Canvas: <span id="canvas-px">800x600 px</span> (<span id="canvas-mm">211.7x158.8 mm</span>)</span>
      </div>
    </header>
    <div class="main-workspace">
      <aside class="toolbar" id="toolbar">
        <button data-tool="select" class="active">Select</button>
        <button data-tool="line">Line</button>
        <button data-tool="rect">Rect</button>
        <button data-tool="pan">Pan</button>
      </aside>
      <main class="canvas-container" id="canvas-container">
        <!-- SVG Canvas will be injected here -->
      </main>
      <aside class="right-panel">
        <div class="panel layers-panel" id="layers-panel">
          <h3>Layers</h3>
          <div class="layer-list" id="layer-list"></div>
          <button id="add-layer-btn">+ New Layer</button>
        </div>
        <div class="panel properties-panel" id="properties-panel">
          <h3>Properties</h3>
          <div id="props-content">Select an object</div>
        </div>
      </aside>
    </div>
  </div>
  <script type="module" src="./main.js"></script>
</body>
</html>`,
  'main.js': `import { AppState } from './01__Core/AppState.js';
import { EventBus } from './01__Core/EventBus.js';
import { SVGCanvas } from './04__SVG/SVGCanvas.js';
import { ToolbarUI } from './02__UI/ToolbarUI.js';
import { LayersPanelUI } from './02__UI/LayersPanelUI.js';
import { PropertiesPanelUI } from './02__UI/PropertiesPanelUI.js';
import { StatusBarUI } from './02__UI/StatusBarUI.js';
import { PanTool } from './03__AppModules/System__Navigation/PanTool.js';
import { ViewBoxController } from './03__AppModules/System__Navigation/ViewBoxController.js';
import { SelectionManager } from './01__Core/SelectionManager.js';
import { LineTool } from './03__AppModules/System__LineworkTools/LineTool.js';
import { RectangleTool } from './03__AppModules/System__LineworkTools/RectangleTool.js';

document.addEventListener('DOMContentLoaded', () => {
  const eventBus = new EventBus();
  const appState = new AppState(eventBus);
  
  const viewBoxController = new ViewBoxController(appState, eventBus);
  const svgCanvas = new SVGCanvas(appState, eventBus, viewBoxController);
  const selectionManager = new SelectionManager(appState, eventBus, svgCanvas);
  
  const toolbar = new ToolbarUI(appState, eventBus);
  const layersPanel = new LayersPanelUI(appState, eventBus, svgCanvas);
  const propsPanel = new PropertiesPanelUI(appState, eventBus, selectionManager);
  const statusBar = new StatusBarUI(appState, eventBus);

  // Initialize Tools
  const tools = {
    'select': null, // default behavior handled by SelectionManager
    'pan': new PanTool(appState, eventBus, viewBoxController),
    'line': new LineTool(appState, eventBus, svgCanvas),
    'rect': new RectangleTool(appState, eventBus, svgCanvas)
  };

  appState.setTools(tools);
  appState.setTool('select');
});`,
  '05__Styles/EditorTheme.css': `
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #1e1e1e; color: #eee; overflow: hidden; }
    #app { display: flex; flex-direction: column; height: 100vh; }
    .top-bar { height: 40px; background: #2d2d2d; display: flex; align-items: center; padding: 0 16px; justify-content: space-between; border-bottom: 1px solid #3d3d3d; }
    .status-bar { display: flex; gap: 16px; font-size: 12px; color: #aaa; }
    .main-workspace { display: flex; flex: 1; overflow: hidden; }
    .toolbar { width: 50px; background: #252526; display: flex; flex-direction: column; gap: 8px; padding: 8px; border-right: 1px solid #3d3d3d; }
    .toolbar button { background: #333; color: #fff; border: none; padding: 8px 0; cursor: pointer; font-size: 10px; border-radius: 4px; }
    .toolbar button.active { background: #007acc; }
    .toolbar button:hover:not(.active) { background: #444; }
    .canvas-container { flex: 1; background: #121212; position: relative; overflow: hidden; cursor: crosshair; }
    .canvas-container svg { width: 100%; height: 100%; }
    .right-panel { width: 250px; background: #252526; border-left: 1px solid #3d3d3d; display: flex; flex-direction: column; }
    .panel { flex: 1; padding: 12px; border-bottom: 1px solid #3d3d3d; overflow-y: auto; }
    .panel h3 { font-size: 14px; margin-bottom: 12px; color: #ccc; text-transform: uppercase; letter-spacing: 0.5px; }
    .layer-item { display: flex; justify-content: space-between; padding: 6px; background: #333; margin-bottom: 4px; border-radius: 4px; cursor: pointer; font-size: 13px; }
    .layer-item.active { background: #007acc; }
    #add-layer-btn { margin-top: 8px; width: 100%; padding: 6px; background: #444; border: none; color: white; border-radius: 4px; cursor: pointer; }
    #add-layer-btn:hover { background: #555; }
    .props-group { margin-bottom: 12px; }
    .props-group label { display: block; font-size: 12px; color: #aaa; margin-bottom: 4px; }
    .props-group input { width: 100%; background: #333; border: 1px solid #444; color: white; padding: 4px 8px; border-radius: 4px; }
    .selected-rect { outline: 1px dashed #007acc; }
  `,
  '01__Core/AppState.js': `
    export class AppState {
      constructor(eventBus) {
        this.eventBus = eventBus;
        this.currentTool = 'select';
        this.tools = {};
        this.layers = [{ id: 'layer-1', name: 'Layer 1', visible: true, locked: false }];
        this.activeLayerId = 'layer-1';
        this.canvasWidth = 800;
        this.canvasHeight = 600;
        this.dpi = 96; // 96 pixels per inch ~ 3.7795 px per mm
        this.pxPerMm = 96 / 25.4;
      }
      setTools(tools) { this.tools = tools; }
      setTool(toolName) {
        if (this.currentTool && this.tools[this.currentTool] && this.tools[this.currentTool].deactivate) {
          this.tools[this.currentTool].deactivate();
        }
        this.currentTool = toolName;
        if (this.tools[this.currentTool] && this.tools[this.currentTool].activate) {
          this.tools[this.currentTool].activate();
        }
        this.eventBus.emit('tool:changed', toolName);
      }
      get activeLayer() { return this.layers.find(l => l.id === this.activeLayerId); }
      addLayer(name) {
        const id = 'layer-' + Date.now();
        this.layers.unshift({ id, name, visible: true, locked: false });
        this.activeLayerId = id;
        this.eventBus.emit('layers:changed', this.layers);
      }
      setActiveLayer(id) {
        this.activeLayerId = id;
        this.eventBus.emit('layers:changed', this.layers);
      }
    }
  `,
  '01__Core/EventBus.js': `
    export class EventBus {
      constructor() { this.listeners = {}; }
      on(event, callback) {
        if (!this.listeners[event]) this.listeners[event] = [];
        this.listeners[event].push(callback);
      }
      emit(event, data) {
        if (this.listeners[event]) {
          this.listeners[event].forEach(cb => cb(data));
        }
      }
    }
  `,
  '01__Core/SelectionManager.js': `
    export class SelectionManager {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.svgCanvas = svgCanvas;
        this.selectedElements = [];
        
        this.svgCanvas.svg.addEventListener('click', (e) => {
          if (this.appState.currentTool !== 'select') return;
          if (e.target === this.svgCanvas.svg || e.target.tagName === 'g') {
            this.clearSelection();
          } else {
            this.selectElement(e.target, e.shiftKey);
          }
        });
      }
      selectElement(el, multi) {
        if (!multi) this.clearSelection();
        if (!this.selectedElements.includes(el)) {
          this.selectedElements.push(el);
          el.setAttribute('stroke', '#007acc'); // temp highlight
        }
        this.eventBus.emit('selection:changed', this.selectedElements);
      }
      clearSelection() {
        this.selectedElements.forEach(el => {
          el.setAttribute('stroke', el.dataset.originalStroke || '#ffffff');
        });
        this.selectedElements = [];
        this.eventBus.emit('selection:changed', this.selectedElements);
      }
    }
  `,
  '04__SVG/SVGCanvas.js': `
    export class SVGCanvas {
      constructor(appState, eventBus, viewBoxController) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.container = document.getElementById('canvas-container');
        
        this.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        this.svg.setAttribute('viewBox', \`0 0 \${appState.canvasWidth} \${appState.canvasHeight}\`);
        this.svg.style.backgroundColor = '#1a1a1a';
        
        // Define canvas rect
        const canvasRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        canvasRect.setAttribute('width', appState.canvasWidth);
        canvasRect.setAttribute('height', appState.canvasHeight);
        canvasRect.setAttribute('fill', '#ffffff');
        this.svg.appendChild(canvasRect);

        this.layerGroups = {};
        this.createLayerGroup(appState.activeLayerId);
        
        this.container.appendChild(this.svg);
        
        this.svg.addEventListener('mousemove', (e) => {
          const pt = this.getSVGPoint(e);
          this.eventBus.emit('cursor:moved', pt);
        });

        this.eventBus.on('layers:changed', () => this.updateLayers());
      }
      
      getSVGPoint(e) {
        const pt = this.svg.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        return pt.matrixTransform(this.svg.getScreenCTM().inverse());
      }

      createLayerGroup(id) {
        if (!this.layerGroups[id]) {
          const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
          g.setAttribute('data-layer-id', id);
          this.svg.appendChild(g);
          this.layerGroups[id] = g;
        }
      }

      updateLayers() {
        this.appState.layers.forEach(l => {
          this.createLayerGroup(l.id);
          // sort according to state? (reverse order in DOM)
        });
      }

      addElement(el) {
        const layerId = this.appState.activeLayerId;
        if (this.layerGroups[layerId]) {
          this.layerGroups[layerId].appendChild(el);
        }
      }
    }
  `,
  '03__AppModules/System__Navigation/ViewBoxController.js': `
    export class ViewBoxController {
      constructor(appState, eventBus) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.viewBox = { x: 0, y: 0, w: appState.canvasWidth, h: appState.canvasHeight };
        this.zoom = 1;
        
        setTimeout(() => {
          this.svg = document.querySelector('svg');
          this.container = document.getElementById('canvas-container');
          this.setupEvents();
          this.updateViewBox();
        }, 100);
      }
      setupEvents() {
        this.container.addEventListener('wheel', (e) => {
          e.preventDefault();
          if (e.button === 1 || e.buttons === 4 || true) { // middle mouse wheel
            const pt = this.getSVGPoint(e);
            const scale = e.deltaY > 0 ? 1.1 : 0.9;
            this.zoom *= scale;
            this.viewBox.w *= scale;
            this.viewBox.h *= scale;
            this.viewBox.x = pt.x - (e.clientX - this.container.getBoundingClientRect().left) * (this.viewBox.w / this.container.clientWidth);
            this.viewBox.y = pt.y - (e.clientY - this.container.getBoundingClientRect().top) * (this.viewBox.h / this.container.clientHeight);
            this.updateViewBox();
          }
        }, { passive: false });
      }
      getSVGPoint(e) {
        const pt = this.svg.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        return pt.matrixTransform(this.svg.getScreenCTM().inverse());
      }
      updateViewBox() {
        this.svg.setAttribute('viewBox', \`\${this.viewBox.x} \${this.viewBox.y} \${this.viewBox.w} \${this.viewBox.h}\`);
        this.eventBus.emit('zoom:changed', (1 / this.zoom) * 100);
      }
      pan(dx, dy) {
        const scaleX = this.viewBox.w / this.container.clientWidth;
        const scaleY = this.viewBox.h / this.container.clientHeight;
        this.viewBox.x -= dx * scaleX;
        this.viewBox.y -= dy * scaleY;
        this.updateViewBox();
      }
    }
  `,
  '03__AppModules/System__Navigation/PanTool.js': `
    export class PanTool {
      constructor(appState, eventBus, viewBoxController) {
        this.appState = appState;
        this.viewBoxController = viewBoxController;
        this.active = false;
        this.isDragging = false;
        this.lastX = 0;
        this.lastY = 0;

        document.getElementById('canvas-container').addEventListener('mousedown', (e) => {
          // Allow panning with right click regardless of tool
          if (this.active || e.button === 2) {
            this.isDragging = true;
            this.lastX = e.clientX;
            this.lastY = e.clientY;
          }
        });
        
        window.addEventListener('mousemove', (e) => {
          if (this.isDragging) {
            const dx = e.clientX - this.lastX;
            const dy = e.clientY - this.lastY;
            this.viewBoxController.pan(dx, dy);
            this.lastX = e.clientX;
            this.lastY = e.clientY;
          }
        });

        window.addEventListener('mouseup', () => {
          this.isDragging = false;
        });
        
        // Prevent context menu on right click in canvas
        document.getElementById('canvas-container').addEventListener('contextmenu', e => e.preventDefault());
      }
      activate() { this.active = true; document.getElementById('canvas-container').style.cursor = 'grab'; }
      deactivate() { this.active = false; document.getElementById('canvas-container').style.cursor = 'crosshair'; }
    }
  `,
  '03__AppModules/System__LineworkTools/LineTool.js': `
    export class LineTool {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.svgCanvas = svgCanvas;
        this.active = false;
        this.drawing = false;
        this.currentLine = null;
        
        this.svgCanvas.svg.addEventListener('mousedown', (e) => {
          if (!this.active || e.button !== 0) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          if (!this.drawing) {
            this.drawing = true;
            this.currentLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            this.currentLine.setAttribute('x1', pt.x);
            this.currentLine.setAttribute('y1', pt.y);
            this.currentLine.setAttribute('x2', pt.x);
            this.currentLine.setAttribute('y2', pt.y);
            this.currentLine.setAttribute('stroke', '#000000');
            this.currentLine.setAttribute('stroke-width', '2');
            this.currentLine.dataset.originalStroke = '#000000';
            this.svgCanvas.addElement(this.currentLine);
          } else {
            this.drawing = false;
            this.currentLine = null;
          }
        });

        this.svgCanvas.svg.addEventListener('mousemove', (e) => {
          if (!this.active || !this.drawing || !this.currentLine) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          this.currentLine.setAttribute('x2', pt.x);
          this.currentLine.setAttribute('y2', pt.y);
        });
      }
      activate() { this.active = true; }
      deactivate() { this.active = false; this.drawing = false; if(this.currentLine && this.currentLine.getAttribute('x1') === this.currentLine.getAttribute('x2')) { this.currentLine.remove(); } this.currentLine = null; }
    }
  `,
  '03__AppModules/System__LineworkTools/RectangleTool.js': `
    export class RectangleTool {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.svgCanvas = svgCanvas;
        this.active = false;
        this.drawing = false;
        this.currentRect = null;
        this.startX = 0;
        this.startY = 0;
        
        this.svgCanvas.svg.addEventListener('mousedown', (e) => {
          if (!this.active || e.button !== 0) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          this.drawing = true;
          this.startX = pt.x;
          this.startY = pt.y;
          this.currentRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          this.currentRect.setAttribute('x', pt.x);
          this.currentRect.setAttribute('y', pt.y);
          this.currentRect.setAttribute('width', 0);
          this.currentRect.setAttribute('height', 0);
          this.currentRect.setAttribute('stroke', '#000000');
          this.currentRect.setAttribute('stroke-width', '2');
          this.currentRect.setAttribute('fill', 'none');
          this.currentRect.dataset.originalStroke = '#000000';
          this.svgCanvas.addElement(this.currentRect);
        });

        this.svgCanvas.svg.addEventListener('mousemove', (e) => {
          if (!this.active || !this.drawing || !this.currentRect) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          let w = pt.x - this.startX;
          let h = pt.y - this.startY;
          
          if (e.shiftKey) {
            const size = Math.max(Math.abs(w), Math.abs(h));
            w = w < 0 ? -size : size;
            h = h < 0 ? -size : size;
          }

          this.currentRect.setAttribute('x', w < 0 ? this.startX + w : this.startX);
          this.currentRect.setAttribute('y', h < 0 ? this.startY + h : this.startY);
          this.currentRect.setAttribute('width', Math.abs(w));
          this.currentRect.setAttribute('height', Math.abs(h));
        });

        this.svgCanvas.svg.addEventListener('mouseup', (e) => {
          if (this.active && this.drawing) {
             this.drawing = false;
             if (this.currentRect && this.currentRect.getAttribute('width') === '0') {
               this.currentRect.remove();
             }
             this.currentRect = null;
          }
        });
      }
      activate() { this.active = true; }
      deactivate() { this.active = false; this.drawing = false; this.currentRect = null; }
    }
  `,
  '02__UI/ToolbarUI.js': `
    export class ToolbarUI {
      constructor(appState, eventBus) {
        this.appState = appState;
        this.buttons = document.querySelectorAll('.toolbar button');
        this.buttons.forEach(btn => {
          btn.addEventListener('click', () => {
            this.appState.setTool(btn.dataset.tool);
          });
        });

        eventBus.on('tool:changed', (toolName) => {
          this.buttons.forEach(btn => {
            if (btn.dataset.tool === toolName) btn.classList.add('active');
            else btn.classList.remove('active');
          });
        });
      }
    }
  `,
  '02__UI/StatusBarUI.js': `
    export class StatusBarUI {
      constructor(appState, eventBus) {
        this.zoomEl = document.getElementById('zoom-level');
        this.posEl = document.getElementById('cursor-pos');
        this.canvasPx = document.getElementById('canvas-px');
        this.canvasMm = document.getElementById('canvas-mm');
        
        eventBus.on('cursor:moved', (pt) => {
          this.posEl.innerText = \`\${Math.round(pt.x)}, \${Math.round(pt.y)}\`;
        });
        
        eventBus.on('zoom:changed', (pct) => {
          this.zoomEl.innerText = \`\${Math.round(pct)}%\`;
        });

        this.updateCanvasInfo(appState);
      }
      updateCanvasInfo(appState) {
        this.canvasPx.innerText = \`\${appState.canvasWidth}x\${appState.canvasHeight} px\`;
        this.canvasMm.innerText = \`\${(appState.canvasWidth / appState.pxPerMm).toFixed(1)}x\${(appState.canvasHeight / appState.pxPerMm).toFixed(1)} mm\`;
      }
    }
  `,
  '02__UI/LayersPanelUI.js': `
    export class LayersPanelUI {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.listEl = document.getElementById('layer-list');
        this.addBtn = document.getElementById('add-layer-btn');
        
        this.addBtn.addEventListener('click', () => {
          this.appState.addLayer('Layer ' + (this.appState.layers.length + 1));
        });

        this.eventBus.on('layers:changed', (layers) => {
          this.render(layers);
        });
        
        this.render(this.appState.layers);
      }
      render(layers) {
        this.listEl.innerHTML = '';
        layers.forEach(l => {
          const div = document.createElement('div');
          div.className = 'layer-item' + (l.id === this.appState.activeLayerId ? ' active' : '');
          div.innerText = l.name;
          div.addEventListener('click', () => this.appState.setActiveLayer(l.id));
          this.listEl.appendChild(div);
        });
      }
    }
  `,
  '02__UI/PropertiesPanelUI.js': `
    export class PropertiesPanelUI {
      constructor(appState, eventBus, selectionManager) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.selectionManager = selectionManager;
        this.panelEl = document.getElementById('props-content');

        this.eventBus.on('selection:changed', (selectedElements) => {
          this.render(selectedElements);
        });
      }
      render(elements) {
        if (elements.length === 0) {
          this.panelEl.innerHTML = 'Select an object';
          return;
        }
        if (elements.length > 1) {
          this.panelEl.innerHTML = \`\${elements.length} objects selected\`;
          return;
        }
        
        const el = elements[0];
        let html = \`<div class="props-group">
          <label>Type: \${el.tagName}</label>
        </div>
        <div class="props-group">
          <label>Stroke Width</label>
          <input type="number" id="prop-stroke-width" value="\${el.getAttribute('stroke-width') || 1}">
        </div>\`;
        
        if (el.tagName === 'rect') {
           html += \`<div class="props-group">
             <label>Width</label>
             <input type="number" id="prop-width" value="\${Math.round(el.getAttribute('width'))}">
           </div>\`;
        }

        this.panelEl.innerHTML = html;

        const swInput = document.getElementById('prop-stroke-width');
        if (swInput) {
          swInput.addEventListener('change', (e) => {
            el.setAttribute('stroke-width', e.target.value);
          });
        }
        
        const wInput = document.getElementById('prop-width');
        if (wInput) {
          wInput.addEventListener('change', (e) => {
            el.setAttribute('width', e.target.value);
          });
        }
      }
    }
  `
};

for (const [filepath, content] of Object.entries(files)) {
  const fullPath = path.join(process.cwd(), filepath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content);
}
console.log('Project setup complete.');
