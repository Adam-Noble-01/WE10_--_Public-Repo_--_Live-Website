
    export class ViewBoxController {
      constructor(appState, eventBus) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.viewBox = { x: 0, y: 0, w: appState.canvasWidth, h: appState.canvasHeight };
        this.zoom = 1;
        
        setTimeout(() => {
          this.container = document.getElementById('canvas-container');
          this.svg = this.container.querySelector('svg');
          this.setupEvents();
          this.updateViewBox();
        }, 100);
      }
  setupEvents() {
    this.container.addEventListener('wheel', (e) => {
      e.preventDefault();
      const pt = this.getSVGPoint(e);
      const scale = e.deltaY > 0 ? 1.1 : 0.9;
      this.zoom *= scale;
      this.viewBox.w *= scale;
      this.viewBox.h *= scale;
      this.viewBox.x = pt.x - (e.clientX - this.container.getBoundingClientRect().left) * (this.viewBox.w / this.container.clientWidth);
      this.viewBox.y = pt.y - (e.clientY - this.container.getBoundingClientRect().top) * (this.viewBox.h / this.container.clientHeight);
      this.updateViewBox();
    }, { passive: false });

    // Right-click panning
    let isPanning = false;
    let lastPanPoint = null;

    this.container.addEventListener('contextmenu', (e) => {
      e.preventDefault(); // Prevent default context menu
    });

    this.container.addEventListener('mousedown', (e) => {
      if (e.button === 2 || e.button === 1) { // Right or Middle click
        isPanning = true;
        lastPanPoint = { x: e.clientX, y: e.clientY };
        this.container.style.cursor = 'grabbing';
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (!isPanning || !lastPanPoint) return;
      const dx = e.clientX - lastPanPoint.x;
      const dy = e.clientY - lastPanPoint.y;
      this.pan(dx, dy);
      lastPanPoint = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 2 || e.button === 1) {
        isPanning = false;
        lastPanPoint = null;
        this.container.style.cursor = '';
      }
    });
  }
      getSVGPoint(e) {
        const pt = this.svg.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        return pt.matrixTransform(this.svg.getScreenCTM().inverse());
      }
      updateViewBox() {
        this.svg.setAttribute('viewBox', `${this.viewBox.x} ${this.viewBox.y} ${this.viewBox.w} ${this.viewBox.h}`);
        this.eventBus.emit('zoom:changed', (1 / this.zoom) * 100);
      }
      pan(dx, dy) {
        const scaleX = this.viewBox.w / this.container.clientWidth;
        const scaleY = this.viewBox.h / this.container.clientHeight;
        this.viewBox.x -= dx * scaleX;
        this.viewBox.y -= dy * scaleY;
        this.updateViewBox();
      }
    }
  