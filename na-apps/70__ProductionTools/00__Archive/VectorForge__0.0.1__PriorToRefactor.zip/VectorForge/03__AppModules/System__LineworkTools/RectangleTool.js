
    export class RectangleTool {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.svgCanvas = svgCanvas;
        this.active = false;
        this.drawing = false;
        this.currentRect = null;
        this.startX = 0;
        this.startY = 0;
        
        this.svgCanvas.svg.addEventListener('mousedown', (e) => {
          if (!this.active || e.button !== 0) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          this.drawing = true;
          this.startX = pt.x;
          this.startY = pt.y;
          this.currentRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          this.currentRect.setAttribute('x', pt.x);
          this.currentRect.setAttribute('y', pt.y);
          this.currentRect.setAttribute('width', 0);
          this.currentRect.setAttribute('height', 0);
          this.currentRect.setAttribute('stroke', '#000000');
          this.currentRect.setAttribute('stroke-width', '2');
          this.currentRect.setAttribute('fill', 'none');
          this.currentRect.dataset.originalStroke = '#000000';
          this.svgCanvas.addElement(this.currentRect);
        });

        this.svgCanvas.svg.addEventListener('mousemove', (e) => {
          if (!this.active || !this.drawing || !this.currentRect) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          let w = pt.x - this.startX;
          let h = pt.y - this.startY;
          
          if (e.shiftKey) {
            const size = Math.max(Math.abs(w), Math.abs(h));
            w = w < 0 ? -size : size;
            h = h < 0 ? -size : size;
          }

          this.currentRect.setAttribute('x', w < 0 ? this.startX + w : this.startX);
          this.currentRect.setAttribute('y', h < 0 ? this.startY + h : this.startY);
          this.currentRect.setAttribute('width', Math.abs(w));
          this.currentRect.setAttribute('height', Math.abs(h));
        });

        this.svgCanvas.svg.addEventListener('mouseup', (e) => {
          if (this.active && this.drawing) {
             this.drawing = false;
             if (this.currentRect && this.currentRect.getAttribute('width') === '0') {
               this.currentRect.remove();
             }
             this.currentRect = null;
          }
        });
      }
      activate() { this.active = true; }
      deactivate() { this.active = false; this.drawing = false; this.currentRect = null; }
    }
  