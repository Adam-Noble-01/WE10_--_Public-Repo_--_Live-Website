export class PathTool {
  constructor(appState, eventBus, svgCanvas) {
    this.appState = appState;
    this.svgCanvas = svgCanvas;
    this.active = false;
    this.drawing = false;
    this.currentPath = null;
    this.points = [];
    
    this.svgCanvas.svg.addEventListener('mousedown', (e) => {
      if (!this.active || e.button !== 0) return;
      const pt = this.svgCanvas.getSVGPoint(e);
      if (!this.drawing) {
        this.drawing = true;
        this.points = [pt];
        this.currentPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        this.currentPath.setAttribute('d', `M ${pt.x} ${pt.y}`);
        this.currentPath.setAttribute('fill', 'none');
        this.currentPath.setAttribute('stroke', '#000000');
        this.currentPath.setAttribute('stroke-width', '2');
        this.currentPath.dataset.originalStroke = '#000000';
        this.svgCanvas.addElement(this.currentPath);
      }
    });

    this.svgCanvas.svg.addEventListener('mousemove', (e) => {
      if (!this.active || !this.drawing || !this.currentPath) return;
      const pt = this.svgCanvas.getSVGPoint(e);
      this.points.push(pt);
      
      let d = `M ${this.points[0].x} ${this.points[0].y}`;
      for (let i = 1; i < this.points.length; i++) {
        d += ` L ${this.points[i].x} ${this.points[i].y}`;
      }
      this.currentPath.setAttribute('d', d);
    });

    this.svgCanvas.svg.addEventListener('mouseup', (e) => {
      if (!this.active || !this.drawing || e.button !== 0) return;
      this.drawing = false;
      this.currentPath = null;
      this.points = [];
    });
  }
  
  activate() { this.active = true; }
  deactivate() { 
    this.active = false; 
    this.drawing = false; 
    this.currentPath = null; 
    this.points = []; 
  }
}
