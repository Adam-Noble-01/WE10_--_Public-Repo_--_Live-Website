
    export class LineTool {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.svgCanvas = svgCanvas;
        this.active = false;
        this.drawing = false;
        this.currentLine = null;
        
        this.svgCanvas.svg.addEventListener('mousedown', (e) => {
          if (!this.active || e.button !== 0) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          if (!this.drawing) {
            this.drawing = true;
            this.currentLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            this.currentLine.setAttribute('x1', pt.x);
            this.currentLine.setAttribute('y1', pt.y);
            this.currentLine.setAttribute('x2', pt.x);
            this.currentLine.setAttribute('y2', pt.y);
            this.currentLine.setAttribute('stroke', '#000000');
            this.currentLine.setAttribute('stroke-width', '2');
            this.currentLine.dataset.originalStroke = '#000000';
            this.svgCanvas.addElement(this.currentLine);
          } else {
            this.drawing = false;
            this.currentLine = null;
          }
        });

        this.svgCanvas.svg.addEventListener('mousemove', (e) => {
          if (!this.active || !this.drawing || !this.currentLine) return;
          const pt = this.svgCanvas.getSVGPoint(e);
          this.currentLine.setAttribute('x2', pt.x);
          this.currentLine.setAttribute('y2', pt.y);
        });
      }
      activate() { this.active = true; }
      deactivate() { this.active = false; this.drawing = false; if(this.currentLine && this.currentLine.getAttribute('x1') === this.currentLine.getAttribute('x2')) { this.currentLine.remove(); } this.currentLine = null; }
    }
  