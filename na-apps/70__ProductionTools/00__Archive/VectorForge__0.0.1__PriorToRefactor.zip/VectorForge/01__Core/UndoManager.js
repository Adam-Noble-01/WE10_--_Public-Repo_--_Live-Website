export class UndoManager {
  constructor(appState, eventBus, svgCanvas) {
    this.appState = appState;
    this.eventBus = eventBus;
    this.svgCanvas = svgCanvas;
    
    this.history = [];
    this.currentIndex = -1;
    this.isUndoRedo = false;

    // Listen to changes to save state
    this.eventBus.on('selection:changed', () => {
      // we could save here but it triggers too often (on highlight)
    });
    
    // The easiest way is to listen to mouseup on canvas
    this.svgCanvas.svg.addEventListener('mouseup', () => {
      setTimeout(() => this.saveState(), 50);
    });

    this.eventBus.on('hotkey:undo', () => this.undo());
    this.eventBus.on('hotkey:redo', () => this.redo());

    // Save initial state
    setTimeout(() => this.saveState(), 200);
  }

  saveState() {
    if (this.isUndoRedo) return;
    
    // We only save if there's an actual change (basic check via innerHTML)
    const currentCode = this.svgCanvas.svg.innerHTML;
    if (this.currentIndex >= 0 && this.history[this.currentIndex].code === currentCode) {
      return;
    }

    // truncate future history if we are in the middle of it
    if (this.currentIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.currentIndex + 1);
    }

    this.history.push({
      code: currentCode,
      layers: JSON.parse(JSON.stringify(this.appState.layers)),
      activeLayerId: this.appState.activeLayerId
    });
    
    this.currentIndex++;
  }

  restoreState(state) {
    this.isUndoRedo = true;
    
    this.eventBus.emit('selection:changed', []);
    this.svgCanvas.svg.innerHTML = state.code;
    this.appState.layers = state.layers;
    this.appState.activeLayerId = state.activeLayerId;
    
    // reconstruct layerGroups
    this.svgCanvas.layerGroups = {};
    Array.from(this.svgCanvas.svg.children).forEach(child => {
      if (child.tagName.toLowerCase() === 'g' && child.hasAttribute('data-layer-id')) {
        this.svgCanvas.layerGroups[child.getAttribute('data-layer-id')] = child;
      }
    });

    this.eventBus.emit('layers:changed', this.appState.layers);
    
    // update code panel
    this.svgCanvas.svg.dispatchEvent(new Event('mouseup'));
    
    setTimeout(() => { this.isUndoRedo = false; }, 50);
  }

  undo() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.restoreState(this.history[this.currentIndex]);
    }
  }

  redo() {
    if (this.currentIndex < this.history.length - 1) {
      this.currentIndex++;
      this.restoreState(this.history[this.currentIndex]);
    }
  }
}
