export const DefaultKeybindings = {
  "undo": [{ key: "z", ctrl: true }],
  "redo": [{ key: "z", ctrl: true, shift: true }, { key: "y", ctrl: true }],
  "delete": [{ key: "Backspace" }, { key: "Delete" }],
  "syncCode": [{ key: "Enter", ctrl: true, shift: true }],
  "tool_select": [{ key: "v" }],
  "tool_line": [{ key: "l" }],
  "tool_rect": [{ key: "r" }],
  "tool_path": [{ key: "p" }]
};
