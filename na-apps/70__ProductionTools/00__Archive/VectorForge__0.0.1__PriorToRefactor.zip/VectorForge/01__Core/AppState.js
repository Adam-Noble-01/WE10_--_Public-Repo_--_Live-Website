
    export class AppState {
      constructor(eventBus) {
        this.eventBus = eventBus;
        this.currentTool = 'select';
        this.tools = {};
        this.layers = [{ id: 'layer-1', name: 'Layer 1', visible: true, locked: false }];
        this.activeLayerId = 'layer-1';
        this.canvasWidth = 800;
        this.canvasHeight = 600;
        this.dpi = 96; // 96 pixels per inch ~ 3.7795 px per mm
        this.pxPerMm = 96 / 25.4;
      }
      setTools(tools) { this.tools = tools; }
      setTool(toolName) {
        if (this.currentTool && this.tools[this.currentTool] && this.tools[this.currentTool].deactivate) {
          this.tools[this.currentTool].deactivate();
        }
        this.currentTool = toolName;
        if (this.tools[this.currentTool] && this.tools[this.currentTool].activate) {
          this.tools[this.currentTool].activate();
        }
        this.eventBus.emit('tool:changed', toolName);
      }
      get activeLayer() { return this.layers.find(l => l.id === this.activeLayerId); }
      addLayer(name) {
        const id = 'layer-' + Date.now();
        this.layers.unshift({ id, name, visible: true, locked: false });
        this.activeLayerId = id;
        this.eventBus.emit('layers:changed', this.layers);
      }
      setActiveLayer(id) {
        this.activeLayerId = id;
        this.eventBus.emit('layers:changed', this.layers);
      }
      renameLayer(id, newName) {
        const l = this.layers.find(l => l.id === id);
        if (l) {
          l.name = newName;
          this.eventBus.emit('layers:changed', this.layers);
        }
      }
      deleteLayer(id) {
        if (this.layers.length <= 1) return; // don't delete last layer
        this.layers = this.layers.filter(l => l.id !== id);
        if (this.activeLayerId === id) {
          this.activeLayerId = this.layers[0].id;
        }
        this.eventBus.emit('layers:changed', this.layers);
      }
    }
  