
    export class SelectionManager {
      constructor(appState, eventBus, svgCanvas) {
        this.appState = appState;
        this.eventBus = eventBus;
        this.svgCanvas = svgCanvas;
        this.selectedElements = [];
        
        this.svgCanvas.svg.addEventListener('click', (e) => {
          if (this.appState.currentTool !== 'select') return;
          // check if it's the background rect
          if (e.target === this.svgCanvas.svg || e.target.tagName === 'svg' || (e.target.tagName === 'rect' && e.target.getAttribute('fill') === '#ffffff' && e.target.parentElement === this.svgCanvas.svg) || e.target.tagName === 'g') {
            this.clearSelection();
          } else {
            this.selectElement(e.target, e.shiftKey);
          }
        });

        // Add keyboard listener for delete via HotkeyManager
        this.eventBus.on('hotkey:delete', () => {
          this.deleteSelected();
        });
      }
      selectElement(el, multi) {
        if (!multi) this.clearSelection();
        if (!this.selectedElements.includes(el)) {
          this.selectedElements.push(el);
          if (!el.dataset.originalStroke) el.dataset.originalStroke = el.getAttribute('stroke') || '';
          el.setAttribute('stroke', '#2563eb'); // temp highlight
        }
        this.eventBus.emit('selection:changed', this.selectedElements);
      }
      clearSelection() {
        this.selectedElements.forEach(el => {
          if (el.dataset.originalStroke !== undefined) {
             if (el.dataset.originalStroke) {
               el.setAttribute('stroke', el.dataset.originalStroke);
             } else {
               el.removeAttribute('stroke');
             }
          }
        });
        this.selectedElements = [];
        this.eventBus.emit('selection:changed', this.selectedElements);
      }
      deleteSelected() {
        if (this.selectedElements.length > 0) {
          this.selectedElements.forEach(el => {
            if (el.parentNode) el.parentNode.removeChild(el);
          });
          this.selectedElements = [];
          this.eventBus.emit('selection:changed', this.selectedElements);
          this.svgCanvas.svg.dispatchEvent(new Event('mouseup')); // to trigger code panel update
        }
      }
    }
  