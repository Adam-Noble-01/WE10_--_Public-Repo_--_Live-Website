import { DefaultKeybindings } from './Keybindings.js';

export class HotkeyManager {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.bindings = DefaultKeybindings;

    window.addEventListener('keydown', (e) => {
      const isInput = e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA';
      
      let matchedAction = null;
      
      for (const [action, combos] of Object.entries(this.bindings)) {
        for (const combo of combos) {
          if (e.key.toLowerCase() === combo.key.toLowerCase() || e.code === combo.key) {
            const ctrlMatch = !!combo.ctrl === (e.ctrlKey || e.metaKey);
            const shiftMatch = !!combo.shift === e.shiftKey;
            const altMatch = !!combo.alt === e.altKey;
            
            if (ctrlMatch && shiftMatch && altMatch) {
               matchedAction = action;
               break;
            }
          }
        }
        if (matchedAction) break;
      }

      if (matchedAction) {
        // Ignore single-key tool shortcuts if we are typing in an input
        if (isInput && !matchedAction.includes('syncCode')) {
           return;
        }

        e.preventDefault();
        this.eventBus.emit(`hotkey:${matchedAction}`);
      }
    });
  }
}
