# GLB Builder Utility - Development Log

**Main File:** [`Na__TrueVision__WhitecardModel__GlbBuilderUtility__Main__.rb`](../Na__TrueVision__WhitecardModel__GlbBuilderUtility__Main__.rb)

---


## Version History

# ---------------------------------------------------------
### GLB Builder Utility - Version 1.3.0 - 10-Feb-2026
- **Twin GLB output per tagged series**: Each tag range now exports two GLBs—a Mesh model and a Linework model—for downstream 3D web app flexibility
- **Mesh model** (`__MeshModel__.glb`): Face geometry only; suffix configurable via `MESH_MODEL_SUFFIX`
- **Linework model** (`__LineworkModel__.glb`): Edge geometry with visibility semantics; suffix via `LINEWORK_MODEL_SUFFIX`
- **LineworkModelHandling module**: New `Na__TrueVision__GlbBuilder__EngineCore__LineworkModelHandling__.rb` for edge-only export
- **Visibility filters**: Linework respects `hidden?`, `soft?`, `smooth?`, and `layer.visible?`; exports only visible hard edges
- **Edge color**: `COLOR_0` (VEC4) vertex attribute from `entity.material.color` (default black)
- **Same transforms**: Uses `Z_UP_TO_Y_UP_MATRIX` and virtual flattening traversal for alignment with mesh GLBs
- **MESH_MODEL_INCLUDE_EDGES constant**: Toggle in GeometryHandling (default `false`) to include edges in mesh GLBs; set to `true` if needed
- **CoreExport**: PerformExport now produces both mesh and linework files per series; success message reports mesh + linework counts
# ---------------------------------------------------------


# ---------------------------------------------------------
### GLB Builder Utility - Version 1.2.0 - 10-Feb-2026
- Complete rewrite of geometry export engine: "Virtual Flattening" architecture
- **Non-destructive export**: recursive DFS traversal with matrix accumulation replaces destructive explosion approach
- Model is never modified during export (no start_operation / abort_operation needed)
- **Mirror correction**: determinant check on accumulated 3x3 matrix detects mirrored geometry; winding order swap [A,B,C] to [A,C,B] restores CCW normals
- **Inverse-transpose normal matrix**: cofactor matrix used for correct normal transformation under non-uniform scale
- **Vertex deduplication**: Hash-based cache keyed on [pos+normal+uv] reduces file size and improves GPU efficiency
- **Binary buffer packing**: `Na__GltfHelpers__AddAccessor` implementation with proper bufferView/accessor creation, 4-byte alignment, min/max bounds
- **Layer0 inheritance**: entities on Layer0 inherit the parent container's layer context during traversal
- **Hard edge export**: non-soft, non-smooth edges exported as glTF LINES primitives (mode 1)
- **UV extraction**: UVQ perspective correction from face.mesh(7) with V-flip for glTF convention
- **Entity naming**: persistent_id-based sanitized names for web viewer debugging
- **Z-up to Y-up**: constant rotation matrix applied at traversal root (determinant +1, no false mirror detection)
- Fixes: "reference to deleted DrawingElement" crash on multi-file export
- Fixes: "Na__GltfHelpers__AddAccessor not implemented" error (BIN chunk was 0 bytes)
- Fixes: empty GLB files with no actual geometry data
# ---------------------------------------------------------


# ---------------------------------------------------------
### GLB Builder Utility - Version 1.1.0 - 10-Feb-2026
- Total rewrite of the GLB Builder Utility.
- Total refactoring of the codebase to improve readability and maintainability.
- Modularisation of the codebase to improve maintainability and separation of concerns.
- Aligned Intelligent SketchUp Tag export ranges with README-defined `##__` prefix system
- Added explicit export buckets for `MainBuildingModel__Existing` (`10__`-`19__`) and `MainBuildingModel__Proposed` (`20__`-`29__`)
- Added `Vegetation` export bucket (`50__`-`59__`) and kept `SceneContextual` at (`60__`-`70__`) to avoid overlap
- Updated parser to accept only strict two-digit prefix tags formatted as `##__...`
- Updated no-match console/help messaging to show full required tag map and naming examples
- Centralised unit conversion and configuration: added shared `INCHES_TO_METERS`, wired Core/Engine modules to use it, and updated UI/export messaging to derive ranges, filenames, and texture/exclusion descriptions from module constants
# ---------------------------------------------------------


# ---------------------------------------------------------
### GLB Builder Utility - Version 1.0.6 - 13-Jan-2025
- Added positioned texture support for SketchUp's texture positioning tool
- Dual-method UV extraction: standard for normal textures, enhanced for positioned
- Automatic detection of positioned textures (rotated, scaled, skewed, translated)
- Proper perspective correction using UVQ coordinates with Q-component handling
- Maintains backward compatibility with existing texture workflows
- Enhanced debugging output to distinguish between standard and positioned textures
# ---------------------------------------------------------


# ---------------------------------------------------------
### GLB Builder Utility - Version 1.0.5 - 13-Jan-2025
- Fixed corruption issue when running script multiple times in one session
- Added comprehensive state reset function to clear all module variables
- Eliminates texture index mismatches between exports
- Ensures clean state for each export without requiring SketchUp restart


# ---------------------------------------------------------
### GLB Builder Utility - Version 1.0.4 - 13-Jan-2025
- Complete rewrite using "apply transforms" explosion approach
- Eliminates complex transformation matrix calculations
- All nested hierarchies temporarily exploded for true global coordinates
- Faces grouped by material and layer for optimized mesh generation
- Single undo operation restores original model state
- Guarantees pixel-perfect coordinate accuracy in GLB output
- Simplified codebase with improved maintainability
# ---------------------------------------------------------

# ---------------------------------------------------------
### Version 1.0.3 - 12-Jan-2025
- Implemented smart leaf container detection for manifold validation
- Added intelligent parent/child container analysis to prevent false positives
- Only validates groups/components containing raw geometry (faces/edges)
- Skips validation on parent containers that only hold nested objects
- Added material handling documentation for downstream texture switching
- Enhanced validation feedback with clear container type identification
- Improved support for complex nested furniture and architectural models
# ---------------------------------------------------------

# ---------------------------------------------------------
### Version 1.0.2 - 12-Jul-2025
- Fixed coordinate system conversion (Z-up to Y-up)
- Fixed unit conversion (inches to meters)
- Fixed texture UV mapping and material colorization
- Added comprehensive progress tracking
# ---------------------------------------------------------

# ---------------------------------------------------------
### Version 1.0.1 - 12-Jul-2025

- Complete rewrite with proper GLB binary format
- Full material and texture support
- Correct GLTF 2.0 JSON structure

---

### Version 1.0.0 - 12-Jul-2025

- Initial implementation with core GLB export functionality
- Texture downscaling feature for optimized file sizes
- Layer filtering system for TrueVision exclusions
